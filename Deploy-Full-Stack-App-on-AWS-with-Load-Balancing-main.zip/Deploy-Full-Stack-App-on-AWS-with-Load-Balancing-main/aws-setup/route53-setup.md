# Route 53 Setup (optional)

1. Create or select a Hosted Zone for your domain.
2. Create an A record (or alias) pointing to your ALB DNS name.
3. (Optional) Use ACM to create/find a validated certificate and enable HTTPS on ALB.
